<?php

// core plugin config
$pluginConfig = array();
$pluginConfig['plugin_name']             = '阿里云对象存储OSS';
$pluginConfig['folder_name']             = 'aliyunoss';
$pluginConfig['plugin_description']      = '阿里云对外提供的海量、安全和高可靠的云存储服务.';
$pluginConfig['plugin_version']          = 1.0;
$pluginConfig['required_script_version'] = 3.4;
$pluginConfig['database_sql']            = 'offline/database.sql';
